from .Knob16 import Knob16

def create_instance(c_instance):
    return Knob16(c_instance)
