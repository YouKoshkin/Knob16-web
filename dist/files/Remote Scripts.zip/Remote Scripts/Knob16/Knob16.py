import Live
from _Framework.ControlSurface import ControlSurface
from _Framework.DeviceComponent import DeviceComponent
from _Framework.SliderElement import SliderElement
from _Framework.InputControlElement import MIDI_CC_TYPE

KNOB_CCS = tuple(range(102, 110))

class Knob16(ControlSurface):
    def __init__(self, c_instance):
        super(Knob16, self).__init__(c_instance)
        self._current_channel = 0 
        self._knobs = [] 

        with self.component_guard():
            self._setup_controls()
            self._setup_device()
            
            # Listeners
            self.song().view.add_selected_track_listener(self._on_track_changed)
            self.song().add_appointed_device_listener(self._on_appointed_device_changed)
            
            # Initial update
            self._on_appointed_device_changed()

    def _setup_controls(self):
        self._knobs = [SliderElement(MIDI_CC_TYPE, self._current_channel, cc) for cc in KNOB_CCS]

    def _setup_device(self):
        self._device = DeviceComponent()
        self._device.set_parameter_controls(tuple(self._knobs))
        self.set_device_component(self._device)

    def handle_sysex(self, midi_bytes):
        # We know this works from your previous logs!
        if len(midi_bytes) >= 7 and midi_bytes[1:4] == (0, 32, 41):
            command = midi_bytes[4]
            if command == 127: # 0x7F
                new_channel = midi_bytes[5]
                if 0 <= new_channel <= 15:
                    self.log_message("Knob16: Switching to Channel " + str(new_channel + 1))
                    self._current_channel = new_channel
                    self._rebuild_controls()

    def _rebuild_controls(self):
        """Forces the knobs to switch channels by recreating them."""
        self.log_message("KNOB16: Rebuilding for Channel " + str(self._current_channel + 1))
        
        with self.component_guard():
            # 1. Totally detach the old knob objects
            if self._device:
                self._device.set_parameter_controls(None)
            
            # 2. DESTROY and RE-CREATE the knobs with the new channel
            # This is the only way to ensure the MIDI map actually updates
            self._knobs = [SliderElement(MIDI_CC_TYPE, self._current_channel, cc) for cc in KNOB_CCS]
            
            # 3. Re-bind the brand new knob objects to the device
            if self._device:
                self._device.set_parameter_controls(tuple(self._knobs))
            
            # 4. Request the hardware rebuild
            self.request_rebuild_midi_map()
            
            # 5. Push names to the app
            device = self.song().appointed_device
            self._send_parameter_names(device)
            
            self.log_message("KNOB16: Rebuild finished.")

    def _on_track_changed(self):
        track = self.song().view.selected_track
        if track and len(track.devices) > 0:
            device_to_select = track.view.selected_device or track.devices[0]
            self.song().appointed_device = device_to_select
        else:
            self.song().appointed_device = None

    def _on_appointed_device_changed(self):
        device = self.song().appointed_device
        if self._device:
            self._device.set_parameter_controls(None)
            self._device.set_device(device)
            self._device.set_parameter_controls(tuple(self._knobs))
            self._device.update()
        
        self._send_parameter_names(device)
        self.request_rebuild_midi_map()

    def _send_parameter_names(self, device):
        if not device or not self._device:
            return

        for index, knob in enumerate(self._knobs):
            if knob and knob.mapped_parameter():
                param = knob.mapped_parameter()
                name = param.name
                
                header = [240, 0, 32, 41, index]
                clean_name = "".join([c for c in name if ord(c) < 128])[:12]
                body = [ord(c) for c in clean_name]
                
                self._send_midi(tuple(header + body + [247]))

    def disconnect(self):
        try:
            self.song().view.remove_selected_track_listener(self._on_track_changed)
            self.song().remove_appointed_device_listener(self._on_appointed_device_changed)
        except:
            pass
        super(Knob16, self).disconnect()