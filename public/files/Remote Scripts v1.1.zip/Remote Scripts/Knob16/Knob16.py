import Live
from _Framework.ControlSurface import ControlSurface
from _Framework.DeviceComponent import DeviceComponent
from _Framework.MixerComponent import MixerComponent
from _Framework.SliderElement import SliderElement
from _Framework.InputControlElement import MIDI_CC_TYPE

KNOB_CCS         = tuple(range(102, 118))  # 16 CCs: 102-117
CMD_CHANNEL      = 127  # 0x7F — switch MIDI channel
CMD_MODE         = 126  # 0x7E — switch script mode
MODE_DEVICE      = 0
MODE_MIXER       = 1
MODE_MACROS      = 2
NUM_MIXER_TRACKS = 8
NUM_MACRO_TRACKS = 4
MACROS_PER_TRACK = 4

class Knob16(ControlSurface):
    def __init__(self, c_instance):
        super(Knob16, self).__init__(c_instance)
        self._current_channel = 0
        self._current_mode    = MODE_DEVICE
        self._knobs           = []
        self._device          = None
        self._mixer           = None
        self._macro_bindings  = []   # list of (knob_index, DeviceParameter)

        with self.component_guard():
            self._knobs = [SliderElement(MIDI_CC_TYPE, self._current_channel, cc) for cc in KNOB_CCS]
            self._setup_mode()

    # ── SysEx ──────────────────────────────────────────────────────

    def handle_sysex(self, midi_bytes):
        if len(midi_bytes) >= 7 and midi_bytes[1:4] == (0, 32, 41):
            command = midi_bytes[4]
            value   = midi_bytes[5]

            if command == CMD_CHANNEL and 0 <= value <= 15:
                self.log_message("Knob16: channel → " + str(value + 1))
                self._current_channel = value
                self._rebuild_controls()

            elif command == CMD_MODE and value in (MODE_DEVICE, MODE_MIXER, MODE_MACROS):
                names = {MODE_DEVICE: "Device", MODE_MIXER: "Mixer", MODE_MACROS: "Macros"}
                self.log_message("Knob16: mode → " + names[value])
                with self.component_guard():
                    self._teardown_current_mode()
                    self._current_mode = value
                    self._setup_mode()

    # ── Mode lifecycle ─────────────────────────────────────────────

    def _teardown_current_mode(self):
        if self._current_mode == MODE_DEVICE:
            if self._device:
                self._device.set_parameter_controls(None)
                self._device.set_device(None)
                self._device = None
            try:
                self.song().view.remove_selected_track_listener(self._on_track_changed)
                self.song().remove_appointed_device_listener(self._on_appointed_device_changed)
            except:
                pass

        elif self._current_mode == MODE_MIXER:
            if self._mixer:
                for i in range(NUM_MIXER_TRACKS):
                    strip = self._mixer.channel_strip(i)
                    strip.set_volume_control(None)
                    strip.set_pan_control(None)
            self._mixer = None
            try:
                self.song().remove_tracks_listener(self._on_mixer_tracks_changed)
            except:
                pass

        elif self._current_mode == MODE_MACROS:
            self._macro_bindings = []
            try:
                self.song().remove_tracks_listener(self._on_macro_tracks_changed)
            except:
                pass

    def _setup_mode(self):
        if self._current_mode == MODE_DEVICE:
            self._setup_device_mode()
        elif self._current_mode == MODE_MIXER:
            self._setup_mixer_mode()
        elif self._current_mode == MODE_MACROS:
            self._setup_macros_mode()

    # ── Device mode ────────────────────────────────────────────────

    def _setup_device_mode(self):
        self._device = DeviceComponent()
        self._device.set_parameter_controls(tuple(self._knobs))
        self.set_device_component(self._device)

        self.song().view.add_selected_track_listener(self._on_track_changed)
        self.song().add_appointed_device_listener(self._on_appointed_device_changed)
        self._on_appointed_device_changed()

    def _on_track_changed(self):
        track = self.song().view.selected_track
        if track and len(track.devices) > 0:
            device_to_select = track.view.selected_device or track.devices[0]
            self.song().appointed_device = device_to_select
        else:
            self.song().appointed_device = None

    def _on_appointed_device_changed(self):
        device = self.song().appointed_device
        if self._device:
            self._device.set_parameter_controls(None)
            self._device.set_device(device)
            self._device.set_parameter_controls(tuple(self._knobs))
            self._device.update()
        self._send_parameter_names(device)
        self.request_rebuild_midi_map()

    def _send_parameter_names(self, device):
        if not device or not self._device:
            self._send_all_labels({})
            return
        labels = {}
        for index, knob in enumerate(self._knobs):
            if knob and knob.mapped_parameter():
                labels[index] = knob.mapped_parameter().name
        self._send_all_labels(labels)

    # ── Mixer mode ─────────────────────────────────────────────────

    def _setup_mixer_mode(self):
        self._mixer = MixerComponent(NUM_MIXER_TRACKS)
        for i in range(NUM_MIXER_TRACKS):
            strip = self._mixer.channel_strip(i)
            strip.set_volume_control(self._knobs[i])
            strip.set_pan_control(self._knobs[i + NUM_MIXER_TRACKS])
        self.song().add_tracks_listener(self._on_mixer_tracks_changed)
        self._send_mixer_labels()
        self.request_rebuild_midi_map()

    def _send_mixer_labels(self):
        labels = {}
        for i in range(NUM_MIXER_TRACKS):
            labels[i]                    = "Vol " + str(i + 1)
            labels[i + NUM_MIXER_TRACKS] = "Pan " + str(i + 1)
        self._send_all_labels(labels)

    def _on_mixer_tracks_changed(self):
        pass  # MixerComponent manages strip lifecycle internally

    # ── Macros mode ────────────────────────────────────────────────

    def _setup_macros_mode(self):
        self._collect_macro_params()
        self.song().add_tracks_listener(self._on_macro_tracks_changed)
        self._send_macro_labels()
        self.request_rebuild_midi_map()

    def _collect_macro_params(self):
        self._macro_bindings = []
        tracks = self.song().tracks
        for track_idx in range(min(NUM_MACRO_TRACKS, len(tracks))):
            track = tracks[track_idx]
            if not track.devices:
                continue
            params = [p for p in track.devices[0].parameters if p.name != 'Device On'][:MACROS_PER_TRACK]
            for param_idx, param in enumerate(params):
                self._macro_bindings.append((track_idx * MACROS_PER_TRACK + param_idx, param))

    def _on_macro_tracks_changed(self):
        self._collect_macro_params()
        self._send_macro_labels()
        self.request_rebuild_midi_map()

    def _send_macro_labels(self):
        labels = {idx: param.name for idx, param in self._macro_bindings if param}
        self._send_all_labels(labels)

    # ── Unified label broadcast ────────────────────────────────────────

    def _send_all_labels(self, labels):
        """Send a SysEx label for every knob index 0-15.
        labels: dict {int: str} — indices absent from the dict receive an empty string."""
        for index in range(16):
            name = labels.get(index, "")
            header = [240, 0, 32, 41, index]
            clean = "".join(c for c in name if ord(c) < 128)[:12]
            body = [ord(c) for c in clean]
            self._send_midi(tuple(header + body + [247]))

    # ── MIDI map override ──────────────────────────────────────────

    def build_midi_map(self, midi_map_handle):
        if self._current_mode == MODE_MACROS:
            for knob_idx, param in self._macro_bindings:
                if param and param.is_enabled:
                    self._knobs[knob_idx].connect_to(param)
        super(Knob16, self).build_midi_map(midi_map_handle)

    # ── Reconnect / refresh ────────────────────────────────────────

    def port_settings_changed(self):
        super(Knob16, self).port_settings_changed()
        self.refresh_state()

    def refresh_state(self):
        super(Knob16, self).refresh_state()
        self.log_message("Knob16: refresh_state — mode=" + str(self._current_mode))
        if self._current_mode == MODE_DEVICE:
            self._on_appointed_device_changed()
        elif self._current_mode == MODE_MIXER:
            self._send_mixer_labels()
            self.request_rebuild_midi_map()
        elif self._current_mode == MODE_MACROS:
            self._collect_macro_params()
            self._send_macro_labels()
            self.request_rebuild_midi_map()

    # ── Rebuild (channel switch) ────────────────────────────────────

    def _rebuild_controls(self):
        self.log_message("Knob16: rebuilding controls for channel " + str(self._current_channel + 1))
        with self.component_guard():
            self._teardown_current_mode()
            self._knobs = [SliderElement(MIDI_CC_TYPE, self._current_channel, cc) for cc in KNOB_CCS]
            self._setup_mode()
        self.request_rebuild_midi_map()

    # ── Lifecycle ──────────────────────────────────────────────────

    def disconnect(self):
        try:
            self._teardown_current_mode()
        except:
            pass
        super(Knob16, self).disconnect()
